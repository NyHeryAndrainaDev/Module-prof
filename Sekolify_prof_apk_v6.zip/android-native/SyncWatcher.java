package com.sekolify.prof;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.TimeUnit;

/**
 * Surveille le PC de l'école en arrière-plan (même app fermée).
 * Toutes les ~15 min : s'il reste des notes non envoyées ET que le PC répond,
 * une notification sonore invite le prof à synchroniser (une seule fois par épisode).
 *
 * L'état (IP du PC, nombre de notes en attente) est écrit par l'app web dans
 * les SharedPreferences "CapacitorStorage" via le plugin @capacitor/preferences.
 */
public class SyncWatcher extends Worker {

    static final String CH_COURS = "cours_v1";
    static final String CH_SYNC = "sync_v1";
    private static final String WORK_NAME = "sekolify_sync_watch";
    private static final String PREFS = "CapacitorStorage";
    private static final int NOTIF_SYNC_ID = 9001;

    public SyncWatcher(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    // ---------------------------------------------------------------- canaux

    static void createChannels(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        Uri sound = soundUri(ctx);
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)                  // son « imposé » : volume alarme
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();

        makeChannel(nm, CH_COURS, "Rappels de cours", "Rappel 10 minutes avant chaque cours", sound, attrs);
        makeChannel(nm, CH_SYNC, "Synchronisation des notes", "Alerte quand le PC de l'école est joignable", sound, attrs);
    }

    private static void makeChannel(NotificationManager nm, String id, String name, String desc,
                                    Uri sound, AudioAttributes attrs) {
        NotificationChannel c = new NotificationChannel(id, name, NotificationManager.IMPORTANCE_HIGH);
        c.setDescription(desc);
        c.setSound(sound, attrs);
        c.enableVibration(true);
        c.setVibrationPattern(new long[]{0, 500, 250, 500, 250, 800});
        c.enableLights(true);
        c.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(c);
    }

    private static Uri soundUri(Context ctx) {
        return Uri.parse("android.resource://" + ctx.getPackageName() + "/raw/alerte");
    }

    // ---------------------------------------------------------- planification

    static void schedule(Context ctx) {
        // Pas de contrainte réseau volontairement : un Wi-Fi local sans internet
        // n'est pas « validé » par Android et bloquerait la tâche.
        PeriodicWorkRequest req = new PeriodicWorkRequest.Builder(SyncWatcher.class, 15, TimeUnit.MINUTES).build();
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, req);
    }

    // ----------------------------------------------------------------- travail

    @NonNull
    @Override
    public Result doWork() {
        try {
            Context ctx = getApplicationContext();
            SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

            int pending = toInt(sp.getString("bg_pending", "0"), 0);
            String ip = sp.getString("bg_ip", "");
            int port = toInt(sp.getString("bg_port", "47831"), 47831);
            boolean last = "1".equals(sp.getString("bg_last_reachable", "0"));

            if (pending <= 0 || ip == null || ip.isEmpty()) {
                if (last) sp.edit().putString("bg_last_reachable", "0").apply();   // nouvel épisode au prochain ajout de notes
                return Result.success();
            }

            boolean reachable = probe(ip, port);
            if (reachable && !last) notifySync(ctx, pending);
            if (reachable != last) sp.edit().putString("bg_last_reachable", reachable ? "1" : "0").apply();
        } catch (Throwable ignored) {
            // on réessaiera au prochain passage
        }
        return Result.success();
    }

    private static int toInt(String s, int def) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return def; }
    }

    private static boolean probe(String ip, int port) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL("http://" + ip + ":" + port + "/hello").openConnection();
            c.setConnectTimeout(2500);
            c.setReadTimeout(2500);
            c.setRequestMethod("GET");
            if (c.getResponseCode() != 200) return false;
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null && sb.length() < 2000) sb.append(line);
            r.close();
            return sb.toString().contains("sekolify");
        } catch (Exception e) {
            return false;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static void notifySync(Context ctx, int pending) {
        createChannels(ctx);
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        Intent open = new Intent(ctx, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(ctx, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        String text = pending + " note(s) non envoyée(s). Il est temps de synchroniser les notes de vos élèves.";
        NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, CH_SYNC)
                .setSmallIcon(ctx.getApplicationInfo().icon)
                .setContentTitle("🔔 Connecté au serveur de l'école")
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setAutoCancel(true)
                .setContentIntent(pi);
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {          // avant Android 8 : pas de canaux
            b.setSound(soundUri(ctx), AudioManager.STREAM_ALARM);
            b.setVibrate(new long[]{0, 500, 250, 500, 250, 800});
        }
        nm.notify(NOTIF_SYNC_ID, b.build());
    }
}
