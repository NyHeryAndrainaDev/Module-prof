package com.sekolify.prof;

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            SyncWatcher.createChannels(this);   // canaux de notification (son d'alarme)
            SyncWatcher.schedule(this);         // surveillance du PC en arrière-plan (~15 min)
        } catch (Throwable ignored) {
            // ne jamais empêcher l'app de démarrer
        }
    }
}
